package com.company;

class NaturalGas extends Building {

    double buildingGasConsumption;
    double gasEmissionFactor;

    NaturalGas(double buildingGasConsumption,double gasEmissionFactor){
        this.buildingGasConsumption = buildingGasConsumption;
        this.gasEmissionFactor = gasEmissionFactor;
    }

    public double getCarbonFootprint(){
        return buildingGasConsumption * gasEmissionFactor;
    }

}
