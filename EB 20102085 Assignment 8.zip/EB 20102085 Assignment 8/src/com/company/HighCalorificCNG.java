package com.company;

public class HighCalorificCng extends Car{

    double fuelConsumption;

    HighCalorificCng(double fuelConsumption){
        this.fuelConsumption = fuelConsumption;
    }

    public double getCarbonFootprint(){
        return fuelConsumption*2252 /100;
    }

}
