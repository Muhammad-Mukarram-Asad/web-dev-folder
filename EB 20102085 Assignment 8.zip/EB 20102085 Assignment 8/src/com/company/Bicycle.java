package com.company;

public class Bicycle implements releaseCarbonFootprint {

    double kmRidden;

    Bicycle(double kmRidden){
        this.kmRidden = kmRidden;
    }

    public double getCarbonFootprint(){
        return 16*kmRidden;
    }





}
