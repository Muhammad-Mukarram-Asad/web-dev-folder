package com.company;

public abstract class Building implements releaseCarbonFootprint {


}
