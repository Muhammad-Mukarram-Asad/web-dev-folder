package com.company;

public class LowCalorificCng extends Car{

    double fuelConsumption;

    LowCalorificCng(double fuelConsumption){
        this.fuelConsumption = fuelConsumption;
    }

    public double getCarbonFootprint(){
        return fuelConsumption*2666 /100;
    }

}
