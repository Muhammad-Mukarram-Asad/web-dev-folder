package com.company;

public class Petrol extends Car{

    double fuelConsumption;

    Petrol(double fuelConsumption){
        this.fuelConsumption = fuelConsumption;
    }

    public double getCarbonFootprint(){
        return fuelConsumption*2392 /100;
    }

}
