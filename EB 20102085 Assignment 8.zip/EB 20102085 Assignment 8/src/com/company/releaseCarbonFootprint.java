package com.company;

public interface releaseCarbonFootprint {

    public double getCarbonFootprint();

}
