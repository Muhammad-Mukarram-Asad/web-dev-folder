package com.company;

public class Electricity extends Building{

    double energyConsumption;
    double electricityEmissionFactor;

    Electricity(double energyConsumption,double electricityEmissionFactor){
        this.energyConsumption = energyConsumption;
        this.electricityEmissionFactor = electricityEmissionFactor;
    }

    public double getCarbonFootprint(){
        return energyConsumption*electricityEmissionFactor;
    }

}
