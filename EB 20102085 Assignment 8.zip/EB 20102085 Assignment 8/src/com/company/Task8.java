package com.company;

public class Task8 {

    public static void main(String[] args) {

        Bicycle bicycle = new Bicycle(4.00);
        System.out.println("Carbon footprint while bicycling 4 km is " + bicycle.getCarbonFootprint());

        System.out.println();

        NaturalGas buildingNaturalGas = new NaturalGas(120.32,11.7);
        System.out.println("Carbon footprint of building by Natural Gas : " + buildingNaturalGas.getCarbonFootprint());

        System.out.println();

        Electricity buildingElectricity = new Electricity(108.0,0.82);
        System.out.println("Carbon footprint of building by Electricity : " + buildingElectricity.getCarbonFootprint());

        System.out.println();

        Diesel carDiesel = new Diesel(53.0);
        System.out.println("Carbon footprint of car on diesel : " + carDiesel.getCarbonFootprint());

        System.out.println();

        Petrol carPetrol = new Petrol(53.0);
        System.out.println("Carbon footprint of car on petrol : " + carPetrol.getCarbonFootprint());

        System.out.println();

        Lpg carLpg = new Lpg(53.0);
        System.out.println("Carbon footprint of car on lpg : " + carLpg.getCarbonFootprint());

        System.out.println();

        LowCalorificCng carLowCng = new LowCalorificCng(53.0);
        System.out.println("Carbon footprint of car on low calorific CNG : " + carLowCng.getCarbonFootprint());

        System.out.println();

        HighCalorificCng carHighCng = new HighCalorificCng(53.0);
        System.out.println("Carbon footprint of car on high calorific CNG : " + carHighCng.getCarbonFootprint());

    }
}
