package com.company;

public abstract class Car implements releaseCarbonFootprint {


}
