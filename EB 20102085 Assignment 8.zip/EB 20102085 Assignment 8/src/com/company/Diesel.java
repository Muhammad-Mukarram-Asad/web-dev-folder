package com.company;

public class Diesel extends Car{

    double fuelConsumption;

    Diesel(double fuelConsumption){
        this.fuelConsumption = fuelConsumption;
    }

    public double getCarbonFootprint(){
        return fuelConsumption*2640 /100;
    }

}
