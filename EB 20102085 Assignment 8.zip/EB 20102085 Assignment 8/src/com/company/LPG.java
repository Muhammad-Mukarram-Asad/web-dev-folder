package com.company;

public class Lpg extends Car{

    double fuelConsumption;

    Lpg(double fuelConsumption){
        this.fuelConsumption = fuelConsumption;
    }

    public double getCarbonFootprint(){
        return fuelConsumption*1665 /100;
    }

}
